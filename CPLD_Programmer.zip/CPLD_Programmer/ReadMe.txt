This firmware is based on STM32L476 Discovery kit. It connects to CPLD with I2C .
To download the CPLD hex file, you need to use HidSend.exe.
The command line for downloading the hex is as below:
HidSend.exe program filename.hex