/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "usb_device.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stdbool.h"
#include "usbd_customhid.h"
#include <string.h>
#include "version.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

#define NVM_CONFIG 0x04
#define EEPROM_CONFIG 0x03

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

/* USER CODE BEGIN PV */
uint8_t tx_buffer[64];		//Variable to store the output data
uint8_t flag = 0;			//Variable to store the button flag
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
/* USER CODE BEGIN PFP */

uint8_t buf[18];//buffer for I2C transmission
uint8_t address=0;//the address of the CPLD
bool addressFound=false;
extern USBD_HandleTypeDef hUsbDeviceFS;

//binary for the hex string
uint8_t data_array[16][16] = {};

//default Hex file, will be replaced when the hex file arrived
char nvmString0[33]   = "010E000000008E3F0300000000000000";
char nvmString1[33]   = "000000000000000000704B1200000000";
char nvmString2[33]   = "0000000000000000000000000000E003";
char nvmString3[33]   = "00000000000000000028000000000000";
char nvmString4[33]   = "00000000000000000000000000000000";
char nvmString5[33]   = "00000000000000000000000000000000";
char nvmString6[33]   = "00303000303030300000E83030003030";
char nvmString7[33]   = "30303033000000000000880000000000";
char nvmString8[33]   = "00000200001422300C3C000000000000";
char nvmString9[33]   = "08000000000000000000100000000000";
char nvmString10[33]  = "00000020000100045D26CC0000020001";
char nvmString11[33]  = "00000201000002000100000201000002";
char nvmString12[33]  = "00010000020001000000010100000000";
char nvmString13[33]  = "00000000000000000000000000000000";
//                               ↓↓ 0 1 2 3 4 5 6 7 8 9 a b c d e f
char nvmString14[33]  = "00000000000000000000000000000000";
//                               ↑↑ 0 1 2 3 4 5 6 7 8 9 a b c d e f
char nvmString15[33]  = "000000000000000000000000000000A5";

char* const nvmString[16] = {
  nvmString0,
  nvmString1,
  nvmString2,
  nvmString3,
  nvmString4,
  nvmString5,
  nvmString6,
  nvmString7,
  nvmString8,
  nvmString9,
  nvmString10,
  nvmString11,
  nvmString12,
  nvmString13,
  nvmString14,
  nvmString15
};



uint8_t readString[256];//The read data from chip


/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */



////////////////////////////////////////////////////////////////////////////////
// ping
////////////////////////////////////////////////////////////////////////////////
void ping()
{
	addressFound=false;

	HAL_Delay(100);
	buf[0] = 0;
	HAL_StatusTypeDef send,receive;
	for (; address < 16; address++)
	{

		send = HAL_I2C_Master_Transmit(&hi2c1, address << 4, buf, 1, HAL_MAX_DELAY);

	    HAL_Delay(1);
	    receive = HAL_I2C_Master_Receive(&hi2c1, address << 4, buf, 1, HAL_MAX_DELAY);

	    if(send == HAL_OK && receive == HAL_OK)
	    {
	    	addressFound=true;
			break;
	    }
	    HAL_Delay(10);
	}
	HAL_Delay(7);
}


/*
 * @return 0 success, 1 failed
 */
int readChipConfigure(void)
{
//	uint8_t upper,lower;
//	uint16_t startAddress=0xcb*2;
//	HAL_StatusTypeDef ret=HAL_OK;


	buf[0] = 0xCB;
	HAL_I2C_Master_Transmit(&hi2c1, address << 4, buf, 1, HAL_MAX_DELAY);

	HAL_Delay(2);

	if(HAL_OK != HAL_I2C_Master_Receive(&hi2c1, address << 4, (readString+0xCB), 52, HAL_MAX_DELAY ))
		return 1;//failed

	HAL_Delay(74);
	return 0;//success

//	ret = HAL_I2C_Master_Receive(&hi2c1, address << 4, (readString+0xCB), 52, HAL_MAX_DELAY );
//	if(ret != HAL_OK)
//		return 1;//failed

//	for(int i=0;i<52;i++)
//	{
//		upper = temp[i]>>4;
//		if(upper>10)
//		{
//			readString[startAddress + 2 * i] = upper - 10 +'A';
//		}
//		else
//		{
//			readString[startAddress + 2 * i] = upper + '0';
//		}
//		lower = temp[i]&0x0F;
//		if(lower>10)
//		{
//			readString[startAddress + 2 * i + 1] = lower - 10 +'A';
//		}
//		else
//		{
//			readString[startAddress + 2 * i + 1] = lower + '0';
//		}
//	}

}


int readChip(void)
{


	int i=0;
	for(;;)
	{
		buf[0] = i;
		HAL_I2C_Master_Transmit(&hi2c1, address << 4, buf, 1, HAL_MAX_DELAY);

		HAL_Delay(1);

		if(HAL_OK != HAL_I2C_Master_Receive(&hi2c1, address << 4, (readString+i), 60, HAL_MAX_DELAY ))
			return 1;//failed

		HAL_Delay(4);
		i+=60;
		if(i+60>256)
			break;
	}

	buf[0] = i;
	HAL_I2C_Master_Transmit(&hi2c1, address << 4, buf, 1, HAL_MAX_DELAY);

	HAL_Delay(1);

	if(HAL_OK != HAL_I2C_Master_Receive(&hi2c1, address << 4, (readString+i), 256-i, HAL_MAX_DELAY ))
		return 1;//failed

	HAL_Delay(77);

//	buf[0] = 0x3C;
//	HAL_I2C_Master_Transmit(&hi2c1, address << 4, buf, 1, HAL_MAX_DELAY);
//
//	HAL_Delay(2);
//
//	if(HAL_OK != HAL_I2C_Master_Receive(&hi2c1, address << 4, (readString+0x3C), 60, HAL_MAX_DELAY ))
//		return 1;//failed
//
//	HAL_Delay(4);
//
//	buf[0] = 0x78;
//	HAL_I2C_Master_Transmit(&hi2c1, address << 4, buf, 1, HAL_MAX_DELAY);
//
//	HAL_Delay(2);
//
//	if(HAL_OK != HAL_I2C_Master_Receive(&hi2c1, address << 4, (readString+0x78), 60, HAL_MAX_DELAY ))
//		return 1;//failed

	return 0;

}



////////////////////////////////////////////////////////////////////////////////
// power cycle
////////////////////////////////////////////////////////////////////////////////
void powercycle()
{
//  digitalWrite(VDD, LOW);
	HAL_GPIO_WritePin(GPIOD, CPLD_PWR_Pin, GPIO_PIN_RESET);

	HAL_Delay(500);

//  digitalWrite(VDD, HIGH);
	HAL_GPIO_WritePin(GPIOD, CPLD_PWR_Pin, GPIO_PIN_SET);

	HAL_Delay(10);

}


////////////////////////////////////////////////////////////////////////////////
// eraseChip
////////////////////////////////////////////////////////////////////////////////
int eraseChip()
{

	buf[0] = 0xE3;

	for (int8_t i = 0x0F; i >=0; i--)
	{
		buf[1] = 0x80|i;

		HAL_I2C_Init(&hi2c1);
		HAL_I2C_Master_Transmit(&hi2c1, address << 4, buf, 2, HAL_MAX_DELAY);
		HAL_I2C_DeInit(&hi2c1);

/* To accommodate for the non-I2C compliant ACK behavior of the Page Erase Byte, we've removed the software check for an I2C ACK
 *  and added the "Wire.endTransmission();" line to generate a stop condition.
 *  - Please reference "Issue 2: Non-I2C Compliant ACK Behavior for the NVM and EEPROM Page Erase Byte"
 *    in the SLG46824/6 (XC revision) errata document for more information. */

		HAL_Delay(30);

	}
	HAL_I2C_Init(&hi2c1);
	HAL_Delay(100);
//	powercycle();
	return 0;

}

////////////////////////////////////////////////////////////////////////////////
// writeChip
// return: 0 success; 1 failed
////////////////////////////////////////////////////////////////////////////////
int writeChip()
{

	HAL_StatusTypeDef writeState;
	// Set the control code to 0x00 since the chip has just been erased
	uint8_t control_code = address << 4;
	control_code |= NVM_CONFIG;

  // Assign each byte to data_array[][] array;
  // http://www.gammon.com.au/progmem

	for (size_t i = 0; i < 16; i++)
	{
	// Pull current page NVM from PROGMEM and place into buffer
		char * ptr = nvmString[i];

		for (size_t j = 0; j < 16; j++)
		{
			char temp[2];
			temp[0] = ptr[2 * j];
			temp[1] = ptr[(2 * j) + 1];
			uint32_t myNum = strtol(&temp[0], NULL, 16);
			data_array[i][j] = (uint8_t) myNum;
		}
	}

	data_array[0xC][0xA] = address;

	buf[0] = 0;
	HAL_I2C_Master_Transmit(&hi2c1, address << 4, buf, 1, HAL_MAX_DELAY);
	HAL_Delay(1);
	HAL_I2C_Master_Receive(&hi2c1, address << 4, buf, 1, HAL_MAX_DELAY);
	HAL_Delay(35);

  // Write each byte of data_array[][] array to the chip
	for (int i = 0; i < 16; i++)
	{
		buf[0] = i * 16;
		memcpy(buf+1,data_array[i],16);
		writeState = HAL_I2C_Master_Transmit(&hi2c1, control_code, buf, 17, HAL_MAX_DELAY);
		HAL_Delay(28);

		if(writeState == HAL_ERROR)
			return 1;
	}

//	powercycle();
	return 0;

}



int resetChip(void)
{

	buf[0] = 0xCB;
	buf[1] = 0x02;
	HAL_I2C_Master_Transmit(&hi2c1, address << 4, buf, 2, HAL_MAX_DELAY);
	HAL_Delay(100);
	return 0;

}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

	uint8_t programState=0;//0 failed, 1 success
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
//  MX_I2C1_Init();
  MX_USB_DEVICE_Init();
  /* USER CODE BEGIN 2 */
//	ping();
//
//	readChipConfigure();
//
//	readChip();
//
//	if(addressFound)
//	{
//		eraseChip();
//
//		writeChip();
//	}
//
//	resetChip();

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {

		//To send the output data when the button is pressed
		if (flag==1)
		{
			flag = 0;


			if(tx_buffer[1]<16)
			{
				USBD_CUSTOM_HID_SendReport(&hUsbDeviceFS, tx_buffer, 64);

				memcpy((nvmString[tx_buffer[1]]),(tx_buffer+2),32);
				if(tx_buffer[1]==15)//last package
				{//write the hex file to the CPLD

					programState = 1;//default failed state
					address=0;
					MX_I2C1_Init();

					ping();
					if(addressFound)
					{

						readChipConfigure();

						readChip();


						eraseChip();

						programState = writeChip();

						resetChip();

						HAL_I2C_DeInit(&hi2c1);
					}



				}
			}

			if(tx_buffer[1] == 32)//get send state
			{
				tx_buffer[1] = programState;
				USBD_CUSTOM_HID_SendReport(&hUsbDeviceFS, tx_buffer, 64);
			}
			else if(tx_buffer[1] == 33)//get version number
			{
//				tx_buffer[1] = programState;
				memcpy(tx_buffer+1, FULL_VERSION_STRING, strlen(FULL_VERSION_STRING));
				USBD_CUSTOM_HID_SendReport(&hUsbDeviceFS, tx_buffer, 64);
			}
		}
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure LSE Drive Capability
  */
  HAL_PWR_EnableBkUpAccess();
  __HAL_RCC_LSEDRIVE_CONFIG(RCC_LSEDRIVE_LOW);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSE|RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.LSEState = RCC_LSE_ON;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.MSICalibrationValue = 0;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_MSI;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 20;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV7;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV2;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Enable MSI Auto calibration
  */
  HAL_RCCEx_EnableMSIPLLMode();
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x00404C74;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOE, AUDIO_RST_Pin|LD_G_Pin|XL_CS_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, LD_R_Pin|M3V3_REG_ON_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(OTG_FS_PowerSwitchOn_GPIO_Port, OTG_FS_PowerSwitchOn_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(OTG_FS_VBUS_GPIO_Port, OTG_FS_VBUS_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOD, CPLD_PWR_Pin|GYRO_CS_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : SAI1_MCK_Pin SAI1_FS_Pin SAI1_SCK_Pin SAI1_SD_Pin */
  GPIO_InitStruct.Pin = SAI1_MCK_Pin|SAI1_FS_Pin|SAI1_SCK_Pin|SAI1_SD_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF13_SAI1;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pin : AUDIO_RST_Pin */
  GPIO_InitStruct.Pin = AUDIO_RST_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(AUDIO_RST_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : MFX_IRQ_OUT_Pin OTG_FS_OverCurrent_Pin */
  GPIO_InitStruct.Pin = MFX_IRQ_OUT_Pin|OTG_FS_OverCurrent_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_EVT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PC0 MAG_INT_Pin MAG_DRDY_Pin */
  GPIO_InitStruct.Pin = GPIO_PIN_0|MAG_INT_Pin|MAG_DRDY_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : VLCD_Pin SEG14_Pin SEG9_Pin SEG13_Pin */
  GPIO_InitStruct.Pin = VLCD_Pin|SEG14_Pin|SEG9_Pin|SEG13_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.Alternate = GPIO_AF11_LCD;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : JOY_CENTER_Pin JOY_LEFT_Pin JOY_RIGHT_Pin JOY_UP_Pin
                           JOY_DOWN_Pin */
  GPIO_InitStruct.Pin = JOY_CENTER_Pin|JOY_LEFT_Pin|JOY_RIGHT_Pin|JOY_UP_Pin
                          |JOY_DOWN_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : MFX_WAKEUP_Pin */
  GPIO_InitStruct.Pin = MFX_WAKEUP_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_EVT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(MFX_WAKEUP_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : LD_R_Pin */
  GPIO_InitStruct.Pin = LD_R_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(LD_R_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : LD_G_Pin */
  GPIO_InitStruct.Pin = LD_G_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(LD_G_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : AUDIO_CLK_Pin */
  GPIO_InitStruct.Pin = AUDIO_CLK_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.Alternate = GPIO_AF13_SAI1;
  HAL_GPIO_Init(AUDIO_CLK_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : QSPI_CLK_Pin QSPI_CS_Pin QSPI_D0_Pin QSPI_D1_Pin
                           QSPI_D2_Pin QSPI_D3_Pin */
  GPIO_InitStruct.Pin = QSPI_CLK_Pin|QSPI_CS_Pin|QSPI_D0_Pin|QSPI_D1_Pin
                          |QSPI_D2_Pin|QSPI_D3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF10_QUADSPI;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pins : MFX_I2C_SLC_Pin MFX_I2C_SDA_Pin */
  GPIO_InitStruct.Pin = MFX_I2C_SLC_Pin|MFX_I2C_SDA_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_OD;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF4_I2C2;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : SEG20_Pin SEG3_Pin SEG19_Pin SEG4_Pin
                           SEG11_Pin SEG12_Pin COM3_Pin */
  GPIO_InitStruct.Pin = SEG20_Pin|SEG3_Pin|SEG19_Pin|SEG4_Pin
                          |SEG11_Pin|SEG12_Pin|COM3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.Alternate = GPIO_AF11_LCD;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : SEG18_Pin SEG5_Pin SEG17_Pin SEG6_Pin
                           SEG16_Pin SEG7_Pin SEG15_Pin SEG8_Pin */
  GPIO_InitStruct.Pin = SEG18_Pin|SEG5_Pin|SEG17_Pin|SEG6_Pin
                          |SEG16_Pin|SEG7_Pin|SEG15_Pin|SEG8_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.Alternate = GPIO_AF11_LCD;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pins : OTG_FS_PowerSwitchOn_Pin OTG_FS_VBUS_Pin */
  GPIO_InitStruct.Pin = OTG_FS_PowerSwitchOn_Pin|OTG_FS_VBUS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : COM0_Pin COM1_Pin COM2_Pin SEG10_Pin */
  GPIO_InitStruct.Pin = COM0_Pin|COM1_Pin|COM2_Pin|SEG10_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.Alternate = GPIO_AF11_LCD;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : CPLD_PWR_Pin */
  GPIO_InitStruct.Pin = CPLD_PWR_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(CPLD_PWR_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : MEMS_SCK_Pin MEMS_MISO_Pin MEMS_MOSI_Pin */
  GPIO_InitStruct.Pin = MEMS_SCK_Pin|MEMS_MISO_Pin|MEMS_MOSI_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF5_SPI2;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pin : GYRO_INT1_Pin */
  GPIO_InitStruct.Pin = GYRO_INT1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_EVT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GYRO_INT1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : USART_TX_Pin USART_RX_Pin */
  GPIO_InitStruct.Pin = USART_TX_Pin|USART_RX_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF7_USART2;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pin : GYRO_CS_Pin */
  GPIO_InitStruct.Pin = GYRO_CS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(GYRO_CS_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : M3V3_REG_ON_Pin */
  GPIO_InitStruct.Pin = M3V3_REG_ON_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(M3V3_REG_ON_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : GYRO_INT2_Pin */
  GPIO_InitStruct.Pin = GYRO_INT2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_EVT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GYRO_INT2_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : XL_CS_Pin */
  GPIO_InitStruct.Pin = XL_CS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(XL_CS_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : XL_INT_Pin */
  GPIO_InitStruct.Pin = XL_INT_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_EVT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(XL_INT_GPIO_Port, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
