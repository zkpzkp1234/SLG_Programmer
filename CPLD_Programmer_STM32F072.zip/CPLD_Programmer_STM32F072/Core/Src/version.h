//Generate Version file using git describe --always --dirty 
  
  
#define MAJOR_VERSION 1  
#define MINOR_VERSION 0  
#define PATCH_VERSION 3  
#define HASH_VERSION "dirty"  
#define IS_DIRTY_VERSION 0  
#define FULL_VERSION_STRING "1.0.3.37158f2 (dirty)"  
  
