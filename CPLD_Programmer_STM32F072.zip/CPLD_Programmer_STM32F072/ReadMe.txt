
07/14/2023
This firmware is a programmer firmware for SLG CPLD. 
It uses STM32F072B-DISCOVERY evaluation board.
It uses "USB USER" port on the eval board. It also use I2C Pins on the PB10 and PB11.
The STM32F072B-DISCOVERY is under production, while the STM32L476-DISCOVERY already stopped production, so this firmware is recommended to use in later projects.

To download the CPLD hex file, you need to use HidSend.exe.
The command line for downloading the hex is as below:
HidSend.exe program filename.hex


