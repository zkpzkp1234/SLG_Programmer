﻿namespace ClassLibrary
{
    public class HidLibrary
    {

    }
}