﻿using System;
using System.IO;
using System.Numerics;
using System.Text;
using HidSharp;
using Microsoft.VisualBasic;

class Program
{
    //HidStream stream;

    static bool compareTwoArray(byte[] a, byte[] b)
    {
        int i = 0;
        if(a.Length!=b.Length)
            return false;

        while (i<a.Length)
        {
            if (a[i] != b[i])
            {
                return false;
            }
            i++;
        }
        return true;
    }

    static void Main(string[] args)
    {
        // Display title as the C# console calculator app.
        Console.WriteLine("Start to download firmware to handle.\r");

        HidDeviceLoader loader = new HidDeviceLoader();
        HidDevice device = loader.GetDevices(1155, 22352).FirstOrDefault();
        if (device == null)
        {
            Console.WriteLine("Failed to find the CPLD downloader.\r");
            Environment.Exit(1);//failed
        }
        else
        {
            Console.WriteLine("CPLD downloader found.\r");
            HidStream stream;
            //if (!device.TryOpen(out stream))
            //{
            //    Console.WriteLine("Failed to open device.\r");
            //    Environment.Exit(1);//failed
            //}

            var message = new byte[64];

            int count = 0;
            byte[] bytes = new byte[64];
            List <string> filelines = new List <string>();
            if(args.Length >=2 )
            {
                if (args[0].Equals("program"))
                {
                    if (File.Exists(args[1]))
                    {
                        byte lineNumber = 1;

                        Console.WriteLine("File "+ args[1] +" exist.\r");
                        Console.WriteLine("Start to read " + args[1] + " \r");

                        const Int32 BufferSize = 128;
                        using (var fileStream = File.OpenRead(args[1]))
                        using (var streamReader = new StreamReader(fileStream, Encoding.UTF8, true, BufferSize))
                        {
                            String line;
                            
                            while ((line = streamReader.ReadLine()) != null && lineNumber <= 16 )
                            {
                                // Process line
                                line = line.Replace("\r\n", string.Empty);
                                if (line.Length==43)
                                {
                                    Console.WriteLine("Read Line " + lineNumber.ToString()  + "\tsuccess.\r");
                                    filelines.Add(line);
                                    lineNumber++;
                                }
                                else
                                {
                                    Console.WriteLine("Hex File format error\r");
                                    Environment.Exit(1);//failed
                                }
                            }
                            Console.WriteLine("File "+args[1]+" read success.\r");
                        }
                        Console.WriteLine("Start to write hex file to programmer.\r");

                        lineNumber = 0;
                        byte retry = 0;
                        while (lineNumber < 16 )
                        {
                            if (!device.TryOpen(out stream))
                            {
                                Console.WriteLine("Failed to open device.\r");
                                Environment.Exit(1);//failed
                            }

                            /*
                             * message format: 
                             * message[0] always 0, used for USB communication protocol
                             * message[1] the actual content length of the follow data
                             * message[2] the line number of current package, totally 16 packages (0-15).
                             *            The 32 means this is a query package, CPLD needs to reply with the actual state.
                             *            The reply should replace the 32 with one of the following actual state
                             *            The actual state coded:   0 download success, 1 download failed.
                             */
                            using (stream)
                            {
                                message[0] = 0;
                                message[1] = 33;//line number+hex content
                                message[2] = lineNumber;
                                for (int i = 0; i < 32; i++)
                                {
                                    message[i + 3] = (byte)(filelines[lineNumber][9+i]);
                                }

                                stream.Write(message, 0, 35);
                                try
                                {
                                    count = stream.Read(bytes);
                                }
                                catch (TimeoutException)
                                {
                                    Console.WriteLine("Read timed out.");
                                    Environment.Exit(1);//failed
                                }

                                

                                if (count > 0 )
                                {
                                    if(compareTwoArray(message,bytes))
                                    {
                                        Console.WriteLine(BitConverter.ToString(bytes) + " Line " + lineNumber.ToString() + "\tsent out success.");
                                        lineNumber++;
                                    }
                                    else
                                    {
                                        retry++;
                                        if(retry>5)
                                        {
                                            Console.WriteLine("The hex file downloading failed, received content is not same as sent");
                                            Environment.Exit(1);//failed
                                        }
                                    }
                                }
                            }
                        }


                        System.Threading.Thread.Sleep(2000);//wait for 2 seconds

                        if (!device.TryOpen(out stream))
                        {
                            Console.WriteLine("Failed to open device.\r");
                            Environment.Exit(1);//failed
                        }

                        using (stream)
                        {
                            message[0] = 0;
                            message[1] = 33;//line number+hex content
                            message[2] = 32;
                            for (int i = 0; i < 32; i++)
                            {
                                message[i + 3] = 0xFF;
                            }

                            stream.Write(message, 0, 35);
                            try
                            {
                                count = stream.Read(bytes);
                            }
                            catch (TimeoutException)
                            {
                                Console.WriteLine("Read timed out.");
                                Environment.Exit(1);//failed
                            }



                            if (count > 0)
                            {
                                Console.WriteLine(BitConverter.ToString(bytes) + " Line 32 sent out success.");
                                if (bytes[2]==0)//success
                                {

                                    Console.WriteLine("Download success");
                                    Environment.Exit(0);
                                    
                                }
                                else
                                {
                                    Console.WriteLine("Download failed");
                                    Environment.Exit(1);
                                }
                            }
                        }


                        Console.WriteLine("The hex file downloading success.");
                        Environment.Exit(0);//success
                    }
                    else
                    {
                        Console.WriteLine("File "+args[1]+" doesn't exist.\r");
                        Environment.Exit(1);//failed
                    }
                }
                else if(args[0].Equals("version"))
                {
                    if (!device.TryOpen(out stream))
                    {
                        Console.WriteLine("Failed to open device.\r");
                        Environment.Exit(1);//failed
                    }

                    /*
                     * message format: 
                     * message[0] always 0, used for USB communication protocol
                     * message[1] the actual content length of the follow data
                     * message[2] the line number of current package, totally 16 packages (0-15).
                     *            The 32 means this is a query package, CPLD needs to reply with the actual state.
                     *            The reply should replace the 32 with one of the following actual state
                     *            The actual state coded:   0 download success, 1 download failed.
                     */
                    using (stream)
                    {
                        message[0] = 0;
                        message[1] = 33;//line number+hex content
                        message[2] = 33;//get version command
                        for (int i = 0; i < 32; i++)
                        {
                            message[i + 3] = 0;
                        }

                        stream.Write(message, 0, 35);
                        try
                        {
                            count = stream.Read(bytes);
                        }
                        catch (TimeoutException)
                        {
                            Console.WriteLine("Read timed out.");
                            Environment.Exit(1);//failed
                        }



                        if (count > 0)
                        {
                            if (compareTwoArray(message, bytes))
                            {
                                Console.WriteLine(" version: " + bytes.ToString()+"\n");
                            }
                            else
                            {
                                Console.WriteLine("failed to get version");
                                Environment.Exit(1);//failed
                            }
                        }
                    }
                }
                else
                {
                    Console.WriteLine("Only support \"program\" and \"version\" command.\r");
                    Environment.Exit(1);//failed
                }
            }
            else
            {
                Console.WriteLine("Missing parameter, use command \"TestHidSend program filename.hex\" to assign the hex file.\r");
            }




            //using (stream)
            //{
            //    message[0] = 0;
            //    message[1] = (byte)sendStr.Length;
            //    for (int i = 0; i < sendStr.Length; i++)
            //    {
            //        message[i + 2] = sendStr[i];
            //    }

            //    stream.Write(message, 0, 2 + (byte)sendStr.Length);
            //    try
            //    {
            //        count = stream.Read(bytes);
            //    }
            //    catch (TimeoutException)
            //    {
            //        Console.WriteLine("Read timed out.");
            //        Environment.Exit(1);//failed
            //    }

            //    if (count > 0)
            //    {
            //        Console.WriteLine("Read out:" + BitConverter.ToString(bytes));
            //        Environment.Exit(0);//success
            //    }
            //}

        }
    }
}